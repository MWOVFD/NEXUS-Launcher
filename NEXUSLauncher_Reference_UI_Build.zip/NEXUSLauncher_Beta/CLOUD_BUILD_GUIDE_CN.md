# NEXUS Launcher 云端 APK 编译说明

当前聊天执行环境没有可用的 Android SDK/Gradle 构建链，因此不能在这里声称 APK 已编译成功。项目内已加入 GitHub Actions 云端编译工作流。

## 手机操作步骤
1. 在 GitHub 创建一个空的 Private 仓库，例如 `NEXUSLauncher`。
2. 解压本 ZIP。
3. 进入 `NEXUSLauncher_Beta` 文件夹，把**里面所有文件和文件夹**上传到 GitHub 仓库根目录；必须包含隐藏目录 `.github/workflows/`。
4. 打开仓库的 **Actions** 页面。
5. 选择 **Build NEXUS Launcher APK**，点击 **Run workflow**。
6. 成功后打开该次运行记录，在 **Artifacts** 下载 `NEXUSLauncher-Beta-0.1.0-debug`。
7. 解压 Artifact，得到 `app-debug.apk`，再安装到 Android 手机测试。

## 失败时
把 Actions 的失败日志截图发回；优先提供最先出现的 `FAILURE`、`e:` 或 `Execution failed` 附近内容，不要发账号密码或密钥。

## 当前功能边界
这是 UI 测试版源码。版本选择和内存滑块是界面交互演示；Minecraft Java 运行核心、真实版本下载、模组/整合包导入、账号认证和服务器 API 尚未接入。启动按钮会明确提示运行核心尚未连接。此 APK 是 Debug 测试包，不是正式发布签名包。
