package com.nexus.launcher

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050A08)
private val Panel = Color(0xFF0C1511)
private val Panel2 = Color(0xFF12221A)
private val Neon = Color(0xFF43F58A)
private val TextMain = Color(0xFFF0FFF5)
private val TextDim = Color(0xFF9AAFA2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 10, 8)
        window.navigationBarColor = android.graphics.Color.rgb(5, 10, 8)
        setContent { NexusApp { msg -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }
    }
}

enum class Page(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("首页", Icons.Default.Home),
    VERSIONS("版本", Icons.Default.Inventory2),
    MODS("模组", Icons.Default.Extension),
    PACKS("整合包", Icons.Default.ViewInAr),
    RESOURCE("资源包", Icons.Default.Palette),
    SHADERS("光影包", Icons.Default.LightMode),
    SETTINGS("设置", Icons.Default.Settings)
}

@Composable
fun NexusApp(toast: (String) -> Unit) {
    var page by remember { mutableStateOf(Page.HOME) }
    var version by remember { mutableStateOf("1.21.4") }
    var ram by remember { mutableFloatStateOf(4096f) }
    var glow by remember { mutableStateOf(true) }
    var language by remember { mutableStateOf("简体中文") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon, background = Bg, surface = Panel, onPrimary = Bg, onBackground = TextMain
    )) {
        Row(
            Modifier.fillMaxSize().background(Bg).padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(
                Modifier.width(112.dp).fillMaxHeight()
                    .background(Panel, RoundedCornerShape(16.dp)).padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("NEXUS", color = Neon, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("Launcher", color = TextMain, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Page.entries.forEach { item ->
                    val selected = page == item
                    val tint by animateColorAsState(if (selected) Neon else TextDim, label = "navTint")
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) Color(0x332FFB76) else Color.Transparent)
                            .clickable { page = item }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(item.icon, contentDescription = item.label, tint = tint, modifier = Modifier.size(21.dp))
                        Text(item.label, color = tint, fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("BETA 0.1.0", color = TextDim, fontSize = 9.sp)
            }

            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    Modifier.fillMaxWidth().height(42.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("NEXUS", color = Neon, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("  |  Minecraft Java Edition", color = TextMain, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.NotificationsNone, null, tint = Neon, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Icon(Icons.Default.Menu, null, tint = Neon, modifier = Modifier.size(21.dp))
                }

                when (page) {
                    Page.HOME -> HomePage(version, { version = it }, ram, { ram = it }, glow, toast)
                    Page.VERSIONS -> LibraryPage("版本管理", "选择和管理 Minecraft Java 版本。当前版本列表为演示数据。", "检查版本", toast)
                    Page.MODS -> LibraryPage("模组管理", "模组安装与 Forge、Fabric、NeoForge 兼容管理将在后续版本接入。", "添加模组", toast)
                    Page.PACKS -> LibraryPage("整合包管理", "支持 .mrpack 整合包导入功能正在开发中。", "导入 .mrpack", toast)
                    Page.RESOURCE -> LibraryPage("资源包管理", "支持 ZIP 资源包导入、预览与启用。", "导入资源包", toast)
                    Page.SHADERS -> LibraryPage("光影包管理", "光影包需要配合兼容的渲染器（如 Iris）。", "导入光影包", toast)
                    Page.SETTINGS -> SettingsPage(glow, { glow = it }, language, { language = it }, toast)
                }
            }
        }
    }
}

@Composable
fun HomePage(
    version: String, setVersion: (String) -> Unit,
    ram: Float, setRam: (Float) -> Unit,
    glow: Boolean, toast: (String) -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier.fillMaxWidth().weight(0.95f)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, if (glow) Neon.copy(alpha = .75f) else Color(0xFF263B30), RoundedCornerShape(14.dp))
        ) {
            Image(
                painter = painterResource(R.drawable.nexus_home_banner),
                contentDescription = "Minecraft-inspired NEXUS home banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(
                    listOf(Color(0xAA020806), Color.Transparent, Color(0x22020806))
                )
            ))
            Column(Modifier.align(Alignment.CenterStart).padding(start = 20.dp)) {
                Text("MINECRAFT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text("JAVA EDITION", color = Neon, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Spacer(Modifier.height(7.dp))
                Text("CREATE  •  EXPLORE  •  SURVIVE", color = Color.White, fontSize = 10.sp)
            }
            Text("NEXUS  •  BETA", Modifier.align(Alignment.TopEnd).padding(12.dp),
                color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        Row(Modifier.fillMaxWidth().weight(1.05f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CardBox(Modifier.weight(1.25f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Inventory2, null, tint = Neon, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("当前版本", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("1.21.4", "1.20.1", "1.19.4").forEach {
                        FilterChip(
                            selected = version == it, onClick = { setVersion(it) },
                            label = { Text(it, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Neon, selectedLabelColor = Bg)
                        )
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text("版本选择为界面演示，尚未下载游戏文件。", color = TextDim, fontSize = 9.sp)
            }

            CardBox(Modifier.weight(1.15f).fillMaxHeight()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, null, tint = Neon, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("内存分配", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Text("${ram.toInt()} MB", Modifier.align(Alignment.CenterHorizontally),
                    color = Neon, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
                Slider(value = ram, onValueChange = setRam, valueRange = 512f..8192f, steps = 14,
                    colors = SliderDefaults.colors(thumbColor = Neon, activeTrackColor = Neon))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("512 MB", color = TextDim, fontSize = 9.sp)
                    Text("8192 MB", color = TextDim, fontSize = 9.sp)
                }
            }

            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                Button(
                    onClick = { toast("Beta 预览版：Minecraft Java 运行核心尚未接入") },
                    Modifier.fillMaxWidth().height(76.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(6.dp))
                    Column {
                        Text("启动游戏", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Text("进入方块世界", fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("JAVA ENGINE NOT CONNECTED", color = TextDim, fontSize = 8.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HomeTile(Modifier.weight(1f), Icons.Default.Extension, "模组", "安装与管理模组")
            HomeTile(Modifier.weight(1f), Icons.Default.ViewInAr, "整合包", "导入与切换整合包")
            HomeTile(Modifier.weight(1f), Icons.Default.Palette, "资源包", "自定义游戏材质")
            HomeTile(Modifier.weight(1f), Icons.Default.LightMode, "光影包", "体验视觉效果")
        }
        Text("欢迎使用 NEXUS Launcher！ 让 Minecraft Java 更加精彩。", color = TextDim, fontSize = 10.sp)
    }
}

@Composable
fun HomeTile(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(modifier.height(54.dp).background(Panel, RoundedCornerShape(11.dp))
        .border(1.dp, Color(0x5534F58A), RoundedCornerShape(11.dp)).padding(horizontal = 9.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Neon, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(7.dp))
        Column {
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text(subtitle, color = TextDim, fontSize = 8.sp)
        }
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp))
        .border(1.dp, Color(0x5534F58A), RoundedCornerShape(14.dp)).padding(12.dp), content = content)
}

@Composable
fun LibraryPage(title: String, description: String, action: String, toast: (String) -> Unit) {
    CardBox(Modifier.fillMaxSize()) {
        Text(title, color = Neon, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(description, color = TextDim, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { toast("Beta 预览：此功能尚未实现") },
            colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg)) {
            Text("＋  $action")
        }
        Spacer(Modifier.height(10.dp))
        Text("此页面为 UI 预览，请勿将当前版本视为完整功能。", color = TextDim, fontSize = 10.sp)
    }
}

@Composable
fun SettingsPage(glow: Boolean, setGlow: (Boolean) -> Unit, language: String,
                 setLanguage: (String) -> Unit, toast: (String) -> Unit) {
    CardBox(Modifier.fillMaxSize()) {
        Text("启动器设置", color = Neon, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("霓虹发光效果", color = TextMain, fontSize = 12.sp)
                Text("控制卡片与按钮的绿色光效", color = TextDim, fontSize = 10.sp)
            }
            Switch(checked = glow, onCheckedChange = setGlow,
                colors = SwitchDefaults.colors(checkedThumbColor = Bg, checkedTrackColor = Neon))
        }
        Spacer(Modifier.height(8.dp))
        Text("语言", color = TextMain, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("简体中文", "繁體中文", "English").forEach {
                FilterChip(selected = language == it, onClick = { setLanguage(it) },
                    label = { Text(it, fontSize = 9.sp) })
            }
        }
        Text("当前 Beta 仅展示语言选项；完整本地化稍后接入。", color = TextDim, fontSize = 9.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { toast("NEXUS Launcher Beta 0.1.0") }) { Text("关于 NEXUS") }
    }
}
